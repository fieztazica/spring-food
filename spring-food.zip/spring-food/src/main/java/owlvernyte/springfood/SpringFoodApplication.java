package owlvernyte.springfood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFoodApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringFoodApplication.class, args);
    }

}
